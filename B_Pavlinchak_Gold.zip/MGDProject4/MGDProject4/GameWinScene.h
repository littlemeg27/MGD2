//
//  GameWinScene.h
//  MGDProject4
//
//  Created by Brenna Pavlinchak on 7/28/15.
//  Copyright (c) 2015 Brenna Pavlinchak. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameWinScene : SKScene

@end
