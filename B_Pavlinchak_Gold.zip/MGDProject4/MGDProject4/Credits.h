//
//  Credits.h
//  MGDProject4
//
//  Created by Brenna Pavlinchak on 7/30/15.
//  Copyright (c) 2015 Brenna Pavlinchak. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface Credits : SKScene

@end
