//
//  GameScene.h
//  MGDProject2
//

//  Copyright (c) 2015 Brenna Pavlinchak. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene <SKPhysicsContactDelegate>

@end
